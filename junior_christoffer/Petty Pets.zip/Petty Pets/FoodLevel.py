def food_level(tryFeed, deltatime, foodLevel):
    # Takes in if user tries to feed the pet, time in minutes since last feeding and its current food level.
    # It returns the updated food level, the mood of the pet and if it was fed.

    foodLevel = foodLevel - (2 * int(deltatime))
    #print(foodLevel)
    #print(round(foodLevel, 2))

    if tryFeed:
        if foodLevel < 70:
            foodLevel = foodLevel + 30
            feed = True
            mood = 'happy'
        else:
            feed = False
            mood = 'happy'
    if not tryFeed:
        if 30 > foodLevel > 0:
            mood = 'angry'
            feed = False
        else:
            print(4)
            mood = 'dead'
            feed = False

    print(foodLevel)

    return [foodLevel, mood, feed]
