import fed
from resulter import send_back

from deltaTime import delta_time
def button_chooser(pressed, foodleveldict):
    print("Pressed button: ", pressed)
    if int(pressed) == 1:
        foodLevel = fed.updater(True, False, fed.foodleveldict)

        sender = send_back(True, False,False,"happy")
    if int(pressed) == 2:
        sleeplevel = fed.updater(True, 60, fed.foodleveldict)
        print("sleppLevel")
        print("hej")

        sender = send_back(False, True, False, "happy", )

    return sender