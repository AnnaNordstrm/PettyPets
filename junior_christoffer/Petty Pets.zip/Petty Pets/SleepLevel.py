import time


def sleep_level(trySleep, sleepLevel, deltatime):

    sleep = False

    sleepLevel = sleepLevel - (0.035 * int(deltatime))
    if trySleep:
        if sleepLevel < 50:

            sleep = True
        else:

            sleep = False
    if sleepLevel < 5:

        sleep = True

    print("Sleep level: ", sleepLevel)
    if sleep:
        while sleepLevel < 100:
            sleepLevel = sleepLevel + 0.24
            time.sleep(60)

    print("Sleep level: ", sleepLevel)

    return sleepLevel, sleep

