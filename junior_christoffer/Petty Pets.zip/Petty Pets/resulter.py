
def send_back(feed, sleep, pet, mood):

    result_dict = { 'message': 0,
        "action": 0,
        "mood": mood
    }
    if feed:
        result_dict["message"] = "The pet was fed"
        result_dict["action"] = "eating"
        mood
    if sleep:
        result_dict["message"] = "The pet is sleeping"
        result_dict["action"] = "sleeping"
    if pet:
        result_dict["message"] = "The pet was petted"
        result_dict["action"] = "petting"

    return result_dict

print(send_back(True, False, False, "Happy"))