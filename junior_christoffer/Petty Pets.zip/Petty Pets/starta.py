def startover():
    with open('starter.txt', 'r+') as ok:
        start = ok.read()
    with open('starter.txt', 'w') as ok:
        ok.write("False")
        return start

