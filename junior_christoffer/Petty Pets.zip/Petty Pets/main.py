from flask import Flask, request, render_template, jsonify
import fed
from chooser import button_chooser


app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')


@app.route('/join', methods=['GET','POST'])
def join():
    text1 = request.form['text1']

    result = {
        "message": button_chooser(text1, fed.foodleveldict)["message"],
        "action": "matas"
        "mood": fed.foodleveldict["mood"]
    }
    return jsonify(result=result)

if __name__ == '__main__':
    app.run(debug=True)
