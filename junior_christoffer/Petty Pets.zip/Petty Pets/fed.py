from FoodLevel import food_level
from getTime import current_time
from deltaTime import delta_time
from starta import startover
from SleepLevel import sleep_level

if startover():
    timesincelastfeed = current_time()
    foodleveldict = {
        "mood": 'happy',
        "foodlevel": 50,
        "timesincelastupdate": timesincelastfeed,
        "sleeplevel": 60}

def updater(tryFeed, trySleep, foodleveldict):
    # Updates the dictionary with saved values
    print(foodleveldict)
    print("timediff: ", delta_time(foodleveldict["timesincelastupdate"]))

    foodLevel = food_level(tryFeed, delta_time(foodleveldict["timesincelastupdate"]), foodleveldict["foodlevel"])
    sleepLevel = sleep_level(trySleep,foodleveldict["sleeplevel"], delta_time(foodleveldict["timesincelastupdate"]))
    foodleveldict["foodlevel"] = foodLevel[0]
    foodleveldict["timesincelastupdate"] = current_time()
    foodleveldict["sleeplevel"] = sleepLevel[0]

    if foodLevel[1] == "happy":
        foodleveldict["mood"] = "happy"
    if foodLevel[1] == "dead":
        foodleveldict["mood"] = "dead"
    if foodLevel[1] == "angry":
        foodleveldict["mood"] = "angry"
        foodleveldict["foodlevel"] = foodLevel[0]
    foodleveldict["mood"] = foodLevel[1]

    return foodleveldict

