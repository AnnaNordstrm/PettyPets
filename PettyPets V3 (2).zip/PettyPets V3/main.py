from flask import Flask, request, render_template, jsonify, url_for, redirect
from starta import opener, updater
from joker import joker
import threading


app = Flask(__name__)


@app.route('/')
def home():
    return render_template('index.html')

@app.route('/login', methods=['GET','POST'])
def login():

    text1 = request.form.get('text3', False)
    print(text1)

    return redirect(url_for('join'))

@app.route('/join', methods=['GET','POST'])
def join():
    text1 = request.form['text1']
    values = updater(opener(),text1)
    print(len(values["action"]))
    joke = joker()

    if values["mood"] != "dead":
        result = {
            "food level": values["food level"],
            "mood": values["mood"],
            "message": values["message"],
            "action": values["action"],
            "build up": joke["buildup"],
            "punchline": joke["punchline"]
            }
    else:
        result = {"mood": "your pet is dead"}
    return jsonify(result=result)

def autoupdate():
    temp = updater(opener(), 0)
    print("hej hej hallå", temp["food level"])
    p1 = threading.Timer(10, autoupdate).start()


autoupdate()


if __name__ == '__main__':
    app.run(debug=True)
