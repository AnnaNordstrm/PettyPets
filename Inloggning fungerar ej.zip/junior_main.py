from flask import Flask, request, render_template, jsonify
from middleware_main import delta_time, current_time
import json
# import time
# from random import randint
# from joker import joker
from joke_provider import jokeProvider

app = Flask(__name__)


class Pet:
  # Class for the pet
   def __init__(self):
      self.pet_name = "pet_name"
      self.username = "username"
      self.password = "password"
      self.timeOfBirth = current_time()
      self.foodLevel = 30
      self.lastFed = current_time()
      self.mood = "angry"
      self.feed = False

   def food_level(self, tryFeed):
    """
    Purpose: To make the object hungrier with time, and if right conditions: feeds the pet +30
    Parameters:
    tryFeed: Boolean, takes in whether user tries to feed the pet.
    Returns: an updated self, mood and feed
    """
    deltatime = delta_time(self.lastFed)[0]
    self.foodLevel = self.foodLevel - (0.05 * deltatime)

    if self.foodLevel >= 70 and tryFeed:
        self.feed = False
        self.mood = 'happy'
    elif self.foodLevel > 0 and tryFeed:
        self.foodLevel += 30
        self.feed = True
        self.mood = 'happy'
    elif self.foodLevel < 30 and self.foodLevel > 0:
        self.mood = 'angry'
    elif self.foodLevel <= 0:
        self.mood = 'dead'

    def pet_level(self):
        pass

    def sleep_level(self):
        pass

pets = [Pet()]

# Lägger till dictionary för användaren
# user_dictionary = {}
#
# def load():
#    global user_dictionary
#    try:
#       with open('sign_up.dat') as f:
#           user_dictionary = json.load(f)
#    except:
#        user_dictionary = {}
#
# def save():
#    with open('sign_up.dat', 'w') as f:
#       json.dump(user_dictionary, f)
#
# def store(username, password):
#    user_dictionary[username] = password
#    return f"{username} assigned to {password}"

@app.route('/', methods=['GET','POST'])
def sign_in():
    return render_template('sign_in_main.html')

# Lägger till route för sign in
@app.route('/login', methods=['GET','POST'])
def login():
    users[0].username = (request.form.get("username"))
    users[0].password = (request.form.get("password"))
    return render_template('home_main.html', username=users[0].username)

@app.route('/sign-up', methods=['GET','POST'])
def sign_up():
    load()
    return render_template('sign_up_main.html')

@app.route('/namer', methods=['GET','POST'])
def namer():
    username = request.args['username']
    password = request.args['password']
    store(username, password)
    save()

    pets[0].pet_name = (request.form.get("pet_name"))
    users[0].username = (request.form.get("username"))
    users[0].password = (request.form.get("password"))
    return render_template('home_main.html', pet_name=pets[0].name, username=users[0].username)

@app.route('/home', methods=['GET','POST'])
def home():
    # Ändrar name till pet_name
    return render_template('home_main.html', pet_name=pets[0].name, username=users[0].username)   #/home splittras till 2 routs, eftersom att vi inte vill att koden i /home_1 körs varje gång

@app.route('/home_1', methods=['GET','POST'])
# ska kallas från javascript
def home_1():
    button_check = request.form['user_action'] #kontrollerar om användare tryckt på knapp och kollar i så fall vilken
    joke = jokeProvider()
    if int(button_check) == 1:
        pets[0].food_level(True)
    else:
        pets[0].food_level(False)
    result = {
        "Mood": pets[0].mood,
        "Feed": pets[0].feed,
        "Joke": joke,
        "Food_level": pets[0].foodLevel
        #
        #"buildup": joke["buildup"],
        #"punchline": joke["punchline"]
        #returneras True eller False beroende på om den äter eller inte
        # behöver implementera sleep och pet.
        }
    return jsonify(result=result)




@app.route('/jokes', methods=['GET','POST'])
def jokes():
    build_up = request.form.get("build_up", False)
    punch_line = request.form.get("punch_line", False)
    print(build_up, punch_line)
    return render_template('jokes_main.html', pet_name=pets[0].name, username=users[0].username)

@app.route('/about', methods=['GET','POST'])
def about():
    return render_template('about_main.html', username=users[0].username)

@app.route('/sign-out', methods=['GET','POST'])
def sign_out():
    # Det måste stå sign_out_main här
    return render_template('sign_out_main.html')

if __name__ == '__main__':
    app.run(debug=True)

