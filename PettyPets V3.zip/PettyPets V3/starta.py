
from FoodLevel import food_level
from deltaTime import delta_time
from getTime import current_time

def opener():
    keys = ["food level", "mood", "lastupdate", "message", "action"]
    with open('Levels.txt') as lines:
        for line in lines:
            values = lines.read().splitlines()

    levels = {str(keys[0]): int(values[0]),
              str(keys[1]): str(values[1]),
              str(keys[2]): int(values[2]),
              str(keys[3]): str(values[3]),
              str(keys[4]): str(values[4])}

    return levels


def updater(levels, pressed):
    print("Pressed button: ", pressed)
    if int(pressed) == 1:

        foodLevel = food_level(pressed, delta_time(levels["lastupdate"]), levels["food level"])
        print(foodLevel[0])
        levels["food level"] = foodLevel[0]
        levels["lastupdate"] = current_time()
        levels["mood"] = foodLevel[1]
        if foodLevel[2]:
            levels["action"] = "matas"
        else:
            levels["action"] = "jag vill inte ha mat"

        closer(levels)
    else:
        foodLevel = food_level(pressed, delta_time(levels["lastupdate"]), levels["food level"])
        levels["food level"] = foodLevel[0]
        levels["lastupdate"] = current_time()
        levels["mood"] = foodLevel[1]
        closer(levels)

    if int(pressed) == 2:
        levels["food level"] = 50
        levels["lastupdate"] = current_time()
        levels["mood"] = "happy"
        levels["message"] = "Hej"
        levels["action"] = "waiting"
        closer(levels)
    return levels

def closer(levels):
    keys = ["food level", "mood", "lastupdate", "message", "action"]
    with open('Levels.txt', 'w') as lines:
        lines.write("\n")
        for i in range(1,6):
            temp = str(levels[keys[i-1]])
            temp = temp + "\n"
            print(temp)
            lines.write(temp)

