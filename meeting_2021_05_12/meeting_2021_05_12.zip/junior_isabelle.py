from flask import Flask, request, render_template, jsonify
import time
from deltatime import delta_time
from get_time import *

import threading
#from starta import opener, updater
#from joker import joker

app = Flask(__name__)

class Pet :
        def __init__ (self):
            self.name = "Lemmy"                     # Name is temporarily not an attribute while testing
            self.timeOfBirth = current_time()
            self.foodLevel = 3
            self.lastFedCheck = current_time()
            self.mood = "angry"
            self.feed = False
            self.actions = "I don't want to eat."

        
        """
        Purpose: To make the object hungrier with time, and if right conditions: feeds the pet +30
        Parameters:
        tryFeed: Boolean, takes in whether user tries to feed the pet.
        Returns: an updated self, mood and feed
        """
        def food_level(self, tryFeed):                          
                                                                
            deltatime = delta_time(self.lastFedCheck)[0]             
            self.foodLevel = self.foodLevel-(3*deltatime)    
            print (self.foodLevel)                                                   
            if self.foodLevel >= 70 and tryFeed:                
                self.feed = False
                self.mood = 'happy'
                self.lastFedCheck = current_time()                                
            elif self.foodLevel > 0 and tryFeed:
                self.foodLevel += 1
                self.feed = True
                self.mood = 'happy'
                self.lastFedCheck = current_time()
            elif self.foodLevel < 30 and self.foodLevel > 0:
                self.mood = 'angry'
                self.lastFedCheck = current_time()
            elif self.foodLevel <= 0:           
                self.mood = 'dead'
                self.lastFedCheck = current_time()              


pets = [Pet()]

"""
def function(arg):
    while arg:
        a = pets.food_level(False)
        print(pets.foodLevel)
        time.sleep(3)
"""

@app.route('/')
def sign_in():
    return render_template('home.html')

@app.route('/sign_up')
def sign_up():
    pass


@app.route('/home', methods=['GET','POST'])    #TODO: skriva in att koden får använda get och post på alla andra routes
def home():                                    #      delete the unecessary returns
    buttonType = request.form['buttonType']

    if int(buttonType) == 1:            #Create               # Selects what to do by checking  buttonType 
        pets[0]=Pet()                       
        result = {"message" : "pet is created in a list!"}
    elif int(buttonType) == 2:          #Feed
        pets[0].food_level(True)
        result = {"Mood" : pets[0].mood, "Foodlevel" : pets[0].foodLevel}          
    elif int(buttonType) == 3:          # Sleeping, yet to be implemented
        result = {"Mood" : pets[0].mood,}
 


    def autoupdate():                   # TODO: en funktion som konstant updaterar gifen.
        updater(0)
        print("hej hej hallå", pets[0].foodLevel)
        p1 = threading.Timer(10, autoupdate).start()
    
    def updater(buttonType):
        print("Pressed button: ", buttonType)
        if int(buttonType) == 2:

            #foodLevel = food_level(pressed, delta_time(levels["lastupdate"]), levels["food level"])
            print(pets[0].foodLevel)
            pets[0].food_level(False)
            #levels["food level"] = foodLevel[0]
            #levels["lastupdate"] = current_time()
            #levels["mood"] = foodLevel[1]
            if pets[0].feed:
                pets[0].actions = "Eating..."
            else:
                pets[0].actions = "I don't want to eat."

            #closer(levels)
        elif int(buttonType)==0:
            pets[0].food_level(False)
        else:
            #foodLevel = food_level(pressed, delta_time(levels["lastupdate"]), levels["food level"])
            #levels["food level"] = foodLevel[0]
            #levels["lastupdate"] = current_time()
            #levels["mood"] = foodLevel[1]
            #closer(levels)
            pass
        #return levels

    autoupdate()
    print("Test")
    return jsonify(esult=result)


@app.route('/jokes')
def jokes():
    pass


@app.route('/about')
def about():
    pass

@app.route('/sign_out')
def sign_out():
    pass


if __name__ == '__main__':
    app.run(debug=True)
"""
    thread = Thread(target=function, args=(True))
    thread.start()
    thread.join()
"""