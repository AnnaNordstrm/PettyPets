
def join_args(text1,text2):
   text1 = text1.upper()
   text2 = text2.upper()
   combine = text1 + " " + text2
   return combine